export const courseContentType = [
  { value: "image", label: "Image" },
  { value: "video", label: "Video" },
  { value: "youtube", label: "Youtube" },
  { value: "text", label: "Text" },
];
