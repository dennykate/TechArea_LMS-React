export interface PostData {
     id: string;
     image: string;
     created_by: string;
     content: string;
     comment_count: number;
     reaction_count: number;
     created_at: string;
     is_reactor: unknown;
   }
   