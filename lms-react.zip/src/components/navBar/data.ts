export const notiData = [
  {
    message: "Polly edited Contact Page",
    time: "36 min ago",
    url: "#",
  },
  {
    message: "Polly edited Contact Page",
    time: "36 min ago",
    url: "#",
  },
  {
    message: "Polly edited Contact Page",
    time: "36 min ago",
    url: "#",
  },
];
