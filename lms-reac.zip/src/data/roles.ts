export const roleData = [
  { label: "Student", value: "1" },
  { label: "Teacher", value: "2" },
  // { label: "Admin", value: "3" },
  { label: "Staff", value: "4" },
];
