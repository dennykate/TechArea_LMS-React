export const subjects = [
  {id: 1, name:"Myanmar"},
  {id: 2, name:"English"},
  {id: 3, name:"Maths"},
  {id: 4, name:"Chemistry"},
  {id: 5, name:"Physics"},
  {id: 6, name:"Biology"},
];
